module.exports = {
    url : "mongodb+srv://mhan823:hiIOlzh8fBJeQ9k6@drawguess.mhzm3.mongodb.net/myFirstDatabase?retryWrites=true&w=majority"
  };